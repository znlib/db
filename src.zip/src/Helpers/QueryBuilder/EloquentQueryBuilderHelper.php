<?php

namespace ZnLib\Db\Helpers\QueryBuilder;

use ZnCore\Base\Helpers\DeprecateHelper;

DeprecateHelper::softThrow();

/**
 * Class EloquentQueryBuilderHelper
 * @package ZnLib\Db\Helpers\QueryBuilder
 * @deprecated
 */
class EloquentQueryBuilderHelper extends \ZnDatabase\Eloquent\Domain\Helpers\QueryBuilder\EloquentQueryBuilderHelper
{

}
