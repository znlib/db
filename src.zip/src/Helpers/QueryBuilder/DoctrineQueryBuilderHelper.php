<?php

namespace ZnLib\Db\Helpers\QueryBuilder;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * Class DoctrineQueryBuilderHelper
 * @package ZnLib\Db\Helpers\QueryBuilder
 * @deprecated
 */
class DoctrineQueryBuilderHelper extends \ZnDatabase\Doctrine\Domain\Helpers\QueryBuilder\DoctrineQueryBuilderHelper
{


}