<?php

namespace ZnLib\Db\Helpers;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * Class SqlHelper
 * @package ZnLib\Db\Helpers
 * @deprecated
 */
class SqlHelper extends \ZnDatabase\Base\Domain\Helpers\SqlHelper
{

}
