<?php

namespace ZnLib\Db\Helpers;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * Class ConfigHelper
 * @package ZnLib\Db\Helpers
 * @deprecated
 */
class ConfigHelper extends \ZnDatabase\Base\Domain\Helpers\ConfigHelper
{

}