<?php

namespace ZnLib\Db\Helpers;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * Class DbHelper
 * @package ZnLib\Db\Helpers
 * @deprecated
 */
class DbHelper extends \ZnDatabase\Base\Domain\Helpers\DbHelper
{

}