<?php

namespace ZnLib\Db\Factories;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * Class ManagerFactory
 * @package ZnLib\Db\Factories
 * @deprecated
 */
class ManagerFactory extends \ZnDatabase\Eloquent\Domain\Factories\ManagerFactory
{

}
