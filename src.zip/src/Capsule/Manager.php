<?php

namespace ZnLib\Db\Capsule;

use ZnCore\Base\Helpers\DeprecateHelper;

DeprecateHelper::softThrow();

/**
 * Class Manager
 * @package ZnLib\Db\Capsule
 * @deprecated
 */
class Manager extends \ZnDatabase\Eloquent\Domain\Capsule\Manager
{

}
