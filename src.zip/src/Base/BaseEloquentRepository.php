<?php

namespace ZnDatabase\Eloquent\Domain\Base;

use ZnCore\Base\Helpers\DeprecateHelper;

DeprecateHelper::softThrow();

/**
 * Class BaseEloquentRepository
 * @package ZnDatabase\Eloquent\Domain\Base
 * @deprecated
 */
abstract class BaseEloquentRepository extends \ZnDatabase\Eloquent\Domain\Base\BaseEloquentRepository
{

}
