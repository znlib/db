<?php

namespace ZnDatabase\Eloquent\Domain\Base;

use ZnCore\Base\Helpers\DeprecateHelper;

DeprecateHelper::softThrow();

/**
 * Class BaseEloquentCrudRepository
 * @package ZnDatabase\Eloquent\Domain\Base
 * @deprecated
 */
abstract class BaseEloquentCrudRepository extends \ZnDatabase\Eloquent\Domain\Base\BaseEloquentCrudRepository
{

}
