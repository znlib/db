<?php

namespace ZnLib\Db\Mappers;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * @deprecated
 */
class TimeMapper extends \ZnDatabase\Base\Domain\Mappers\TimeMapper
{

}
