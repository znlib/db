<?php

namespace ZnLib\Db\Mappers;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * @deprecated
 */
class PathMapper extends \ZnDatabase\Base\Domain\Mappers\PathMapper
{

}
