<?php

namespace ZnLib\Db\Mappers;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * @deprecated
 */
class GmpMapper extends \ZnDatabase\Base\Domain\Mappers\GmpMapper
{

}
