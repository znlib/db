<?php

namespace ZnLib\Db\Mappers;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * @deprecated
 */
class BinaryMapper extends \ZnDatabase\Base\Domain\Mappers\BinaryMapper
{

}
