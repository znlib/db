<?php

namespace ZnLib\Db\Mappers;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * Class DefaultMapper
 * @package ZnLib\Db\Mappers
 * @deprecated 
 */
class DefaultMapper extends \ZnDatabase\Base\Domain\Mappers\DefaultMapper
{

}
