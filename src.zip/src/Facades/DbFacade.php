<?php

namespace ZnLib\Db\Facades;

\ZnCore\Base\Helpers\DeprecateHelper::softThrow();

/**
 * Class DbFacade
 * @package ZnLib\Db\Facades
 * @deprecated
 */
class DbFacade extends \ZnDatabase\Base\Domain\Facades\DbFacade
{

}
